import styled from 'styled-components';

export const Container = styled.div`
  //
`;

export const Form = styled.form`
  //
`;

export const FormTitle = styled.h2`
  //
`;
