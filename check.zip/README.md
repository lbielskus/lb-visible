okay now lefft for me precising this website before production. What i want to do with you:

1. I have pricingplans which are products, what info i should save in database from cms for monthly payment integration via this website? i already use stripe so its should be easy. just this my product have simple price which is set in products cms. and for example if person choose to pay for yearly, e will get that price, but if monthly it will be extra 10eur. for now i just put simple to add 10 eur to price in pricingplans component which i believe is wrong way. After click of select plan will apearing as products in cart. How to make everything work correctly? for example if i would like to let user choose yearly and pay that smaller amount for yearly payment and bigger for monthly payment? i know by using stripe i could achieve automated payments from my clients cards each month also. so i want those cool features on my website also.

'use client';

import React, { useState } from 'react';
import toast from 'react-hot-toast';
import { useCart } from '../lib/CartContext';
import styles from '../styles/buttonStyles3.module.scss';

interface Product {
id: string;
title: string;
price: number | string;
features?: string[];
description?: string;
}

interface Props {
products: Product[];
}

const formatPrice = (price: number | string): string => {
const numeric = typeof price === 'string' ? parseFloat(price) : price;
return numeric.toFixed(2);
};

const PricingPlans: React.FC<Props> = ({ products }) => {
const [billingCycle, setBillingCycle] = useState<'yearly' | 'monthly'>(
'yearly'
);
const { addProduct } = useCart();

const getDisplayPrice = (price: number | string): string => {
const numeric = typeof price === 'string' ? parseFloat(price) : price;
return billingCycle === 'yearly'
? formatPrice(numeric)
: formatPrice(numeric + 10);
};

// Sort order for display
const sorted = [...products].sort((a, b) => {
const order = ['Beginner', 'Advanced', 'Business'];
return order.indexOf(a.title) - order.indexOf(b.title);
});

return (

<section className='py-16 px-4 sm:px-8'>
<div className='max-w-2xl mx-auto text-center mb-12 bg-[rgba(31,41,55,0.45)] backdrop-blur-xl rounded-3xl p-4'>
<h2 className='text-4xl font-bold text-white'>Plans built to scale</h2>
<p className='text-gray-300 mt-2'>
Choose a monthly or yearly plan and grow your online presence.
</p>

        <div className='mt-4 flex justify-center items-center gap-4'>
          <span className='text-white'>Monthly</span>
          <button
            onClick={() =>
              setBillingCycle(billingCycle === 'yearly' ? 'monthly' : 'yearly')
            }
            className={`relative w-12 h-6 flex items-center rounded-full px-1 transition-colors duration-300 focus:outline-none ${
              billingCycle === 'yearly' ? 'bg-pink-500' : 'bg-gray-400'
            }`}
          >
            <span
              className={`w-5 h-5 bg-white rounded-full shadow-md transform transition-transform duration-300 ${
                billingCycle === 'yearly' ? 'translate-x-6' : 'translate-x-0'
              }`}
            />
          </button>
          <span className='text-white'>Yearly</span>
        </div>
      </div>

      <div className='grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 justify-center max-w-screen-xl mx-auto'>
        {sorted.map((product) => (
          <div
            key={product.id}
            className='max-w-sm w-full bg-[rgba(31,41,55,0.45)] backdrop-blur-xl border border-white/10 shadow-xl rounded-3xl p-6 text-white flex flex-col justify-between hover:shadow-2xl transition-all'
          >
            <div>
              <h3 className='text-2xl font-bold text-center mb-4'>
                {product.title}
              </h3>

              <ul className='text-sm space-y-2 mb-6'>
                {(product.features?.length
                  ? product.features
                  : product.description?.split(/<br\s*\/?>|\n/)
                )?.map((feature, idx) => {
                  const clean = feature
                    ?.replace(/<[^>]*>/g, '') // strip HTML
                    ?.replace(/^✔/, '') // remove leading ✔
                    ?.replace(/[\u200B-\u200D\uFEFF]/g, '') // remove invisible chars
                    ?.trim();
                  return (
                    clean && (
                      <li key={idx} className='flex items-start gap-2'>
                        <span className='text-green-400'>✔</span>
                        <span className='text-gray-200'>{clean}</span>
                      </li>
                    )
                  );
                })}
              </ul>
            </div>

            <div className='text-center mt-auto'>
              <p className='text-sm text-gray-200'>From</p>
              <p className='text-3xl font-bold text-pink-400 mb-4'>
                € {getDisplayPrice(product.price)}
              </p>
              <button
                onClick={() => {
                  addProduct(product.id);
                  toast.success('Item added to cart!');
                }}
                type='button'
                className={`${styles['draw-border']} w-full text-center py-2.5`}
              >
                Select
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>

);
};

export default PricingPlans;

2. Login/Register user working nice with firebase, but what im worried about that its not fully ready to production. first of all i need email verifications for accounts, to make that i need first host website and connect correct domain and email i think right? because now anyone could type any email and its not gonna verify them. For example maybe its logical to make auto sending emails with verification code? is it a lot of job? also could you check if register validations is all set, or you can improve something?

'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/router';
import { AiOutlineMail, AiOutlineUnlock } from 'react-icons/ai';
import { BsPerson } from 'react-icons/bs';
import { RiLockPasswordLine } from 'react-icons/ri';
import Link from 'next/link';
import Image from 'next/image';
import { registerUser } from '../../lib/registerUser';

interface InputErrors {
[key: string]: string;
}

const SignupForm = () => {
const [data, setData] = useState({
fullName: '',
email: '',
password: '',
confirmPassword: '',
});

const [validationErrors, setValidationErrors] = useState<InputErrors>({});
const [submitError, setSubmitError] = useState('');
const [loading, setLoading] = useState(false);
const router = useRouter();

const validateData = () => {
const errors: InputErrors = {};
if (data.fullName.length < 4) {
errors.fullName = 'Full name must be at least 4 characters';
} else if (data.fullName.length > 30) {
errors.fullName = 'Full name should be less than 30 characters';
}
if (data.password.length < 6) {
errors.password = 'Password should be at least 6 characters';
}
if (data.password !== data.confirmPassword) {
errors.confirmPassword = "Passwords don't match";
}

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;

};

const handleSignup = async (e: React.FormEvent<HTMLFormElement>) => {
e.preventDefault();
if (!validateData()) return;

    try {
      setLoading(true);
      await registerUser(
        data.fullName,
        data.email,
        data.password,
        process.env.NEXT_PUBLIC_CLIENT_ID as string
      );
      router.push('/login');
    } catch (err: any) {
      setSubmitError(err?.message || 'Signup failed');
    } finally {
      setLoading(false);
    }

};

const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
setData({ ...data, [e.target.name]: e.target.value });
};

return (

<section className='flex items-center justify-center min-h-screen px-4 py-8'>
<div className='w-full max-w-md bg-white/10 backdrop-blur-xl border border-white/20 text-gray-800 rounded-xl shadow-2xl p-8'>
<Link
          href='/'
          className='mb-6 flex justify-center gap-2 items-center text-xl font-semibold hover:opacity-75'
        >
<Image
            src='https://res.cloudinary.com/dcknlnne1/image/upload/c_pad,b_auto:predominant,fl_preserve_transparency/v1709827936/favicon-32x32_rllh9h.jpg?_s=public-apps'
            alt='Logo'
            width={28}
            height={28}
          />
<span className='text-purple-400'>Websites</span>
</Link>

        <h1 className='text-3xl font-bold text-center mb-6 text-gray-700'>
          Create Account
        </h1>

        <form className='space-y-4' onSubmit={handleSignup}>
          <div className='flex items-center gap-3'>
            <BsPerson />
            <input
              type='text'
              name='fullName'
              placeholder='Full Name'
              value={data.fullName}
              onChange={handleInputChange}
              className='w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2 placeholder-gray-800 text-gray-800 focus:outline-none focus:ring-2 focus:ring-purple-500'
            />
          </div>
          {validationErrors.fullName && (
            <p className='text-red-400 text-sm'>{validationErrors.fullName}</p>
          )}

          <div className='flex items-center gap-3'>
            <AiOutlineMail />
            <input
              type='email'
              name='email'
              placeholder='Email'
              value={data.email}
              onChange={handleInputChange}
              className='w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2 placeholder-gray-800 text-gray-800 focus:outline-none focus:ring-2 focus:ring-purple-500'
            />
          </div>

          <div className='flex items-center gap-3'>
            <AiOutlineUnlock />
            <input
              type='password'
              name='password'
              placeholder='Password'
              value={data.password}
              onChange={handleInputChange}
              className='w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2 placeholder-gray-800 text-gray-800 focus:outline-none focus:ring-2 focus:ring-purple-500'
            />
          </div>
          {validationErrors.password && (
            <p className='text-red-400 text-sm'>{validationErrors.password}</p>
          )}

          <div className='flex items-center gap-3'>
            <RiLockPasswordLine />
            <input
              type='password'
              name='confirmPassword'
              placeholder='Confirm Password'
              value={data.confirmPassword}
              onChange={handleInputChange}
              className='w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2 placeholder-gray-800 text-gray-800 focus:outline-none focus:ring-2 focus:ring-purple-500'
            />
          </div>
          {validationErrors.confirmPassword && (
            <p className='text-red-400 text-sm'>
              {validationErrors.confirmPassword}
            </p>
          )}

          <button
            type='submit'
            disabled={loading}
            className='w-full bg-purple-700 hover:bg-purple-600 transition text-white font-medium py-2.5 rounded-xl'
          >
            {loading ? 'Processing...' : 'Sign Up'}
          </button>

          {submitError && (
            <p className='text-red-400 text-sm text-center'>{submitError}</p>
          )}

          <p className='text-sm text-center text-gray-800/70 mt-2'>
            Already have an account?{' '}
            <Link href='/login' className='text-purple-300 hover:underline'>
              Log in
            </Link>
          </p>
        </form>

        {/* "To Home Page" button (same style as LoginForm) */}
        <Link
          href='/'
          className='mt-6 inline-block w-full text-center bg-white/10 border border-primary/20 hover:bg-white/20 text-primary font-medium py-2.5 rounded-xl transition duration-300 backdrop-blur-md'
        >
          To Home Page
        </Link>
      </div>
    </section>

);
};

export default SignupForm;

3. Cookies - Im supposed to make coockies accept popup in lithuania right? is it difficult? you can guide me to make my e commerce store fully legitimate for europe?

You're thinking in the right direction for production. Let’s break it down and make sure your whole flow is solid, scalable, and compliant:

✅ 1. Stripe Integration for Yearly & Monthly Plans (Recurring)
🔥 Goal:
Let users:

Choose a pricing plan (Beginner, Advanced, Business)

Pick between monthly or yearly

Checkout with Stripe

Automatically get billed every month/year

🔧 Firestore Model (CMS-side):
You need to store the correct Stripe price ID for each billing cycle in your product CMS:

ts
Copy
Edit
{
title: "Beginner",
description: "...",
features: [...],
monthlyPriceId: "price_xxx_monthly",
yearlyPriceId: "price_xxx_yearly",
basePrice: 12.99 // for display
}
☝️ These price_xxx values come from Stripe Dashboard when you create recurring products with prices.

⚙️ On PricingPlans:
Don’t add €10 manually. That's wrong for billing logic.

Instead, use the correct Stripe priceId based on selected billing cycle.

Update your addProduct to include priceId:

ts
Copy
Edit
onClick={() => {
const priceId = billingCycle === 'yearly' ? product.yearlyPriceId : product.monthlyPriceId;
addProduct({ id: product.id, title: product.title, priceId, billingCycle });
toast.success('Plan added to cart');
}}
In your Cart + Checkout logic, forward the selected priceId to Stripe's /create-checkout-session.

💳 Stripe Checkout Session Setup (Backend):
ts
Copy
Edit
const session = await stripe.checkout.sessions.create({
payment_method_types: ['card'],
mode: 'subscription',
line_items: [
{
price: selectedPriceId,
quantity: 1,
},
],
success_url: `${domain}/success`,
cancel_url: `${domain}/pricing`,
});
You get full recurring billing for that customer, automatically managed by Stripe.

✅ 2. Firebase Auth + Email Verification (Production-Ready)
🚨 Security/Validation:
You're missing:

Email format validation

Email verification flow

Block login if email is not verified

🔧 Fix Registration:
Inside your registerUser method, trigger email verification:

ts
Copy
Edit
import { createUserWithEmailAndPassword, sendEmailVerification } from 'firebase/auth';

export const registerUser = async (fullName, email, password, clientId) => {
const userCredential = await createUserWithEmailAndPassword(auth, email, password);

await sendEmailVerification(userCredential.user);

// Save user info to Firestore...
};
✅ When user registers, they’ll get a verification email.
You must also block dashboard/login routes if their user.emailVerified === false.

✅ 3. Cookie Consent (EU/GDPR Compliance for Lithuania)
🎯 Mandatory for:
Any tracking (Google Analytics, Facebook Pixel)

Marketing cookies

🧠 Strategy:
Show banner (on first visit)

Save consent in localStorage

Load analytics only if accepted

💡 Solution:
Use next-cookie-consent, or build a minimal banner:

tsx
Copy
Edit
useEffect(() => {
if (!localStorage.getItem('cookieConsent')) {
setShowBanner(true);
}
}, []);

const acceptCookies = () => {
localStorage.setItem('cookieConsent', 'true');
setShowBanner(false);
};
💬 Banner UI:
tsx
Copy
Edit
{showBanner && (

  <div className='fixed bottom-0 left-0 w-full bg-white/90 text-gray-800 text-sm p-4 backdrop-blur-md z-50 flex items-center justify-between'>
    <p>This website uses cookies to ensure the best experience. </p>
    <button onClick={acceptCookies} className='ml-4 px-4 py-2 bg-green-500 text-white rounded-lg'>Accept</button>
  </div>
)}
🔁 Summary
Task	Status	Priority
Stripe recurring billing	❌ Needs correct priceId usage and /checkout-session logic	🔴 High
Firebase email verification	⚠️ Partial (missing verification + block unverified users)	🔴 High
Cookie popup (EU compliance)	❌ Not implemented	🟡 Medium

Let me know what to start implementing step-by-step — Stripe integration first, email auth hardening, or GDPR cookie banner.

///

✅ Action Plan
You should now fix these files:

components/Products.tsx

components/PricingPlans.tsx

components/Banner.tsx

components/Hero.js

components/Form/SignupForm.tsx

public/favicon-32x32.png (check file validity)

next.config.js (optional: optimize images.domains)

tailwind.config.js (for default styles like text-size-adjust)

Let me know if you want full fixed versions for any of them.
