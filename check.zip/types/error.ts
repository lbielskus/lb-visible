export interface InputErros {
    [key: string]: string;
}