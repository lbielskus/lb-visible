import Head from 'next/head';

export default function PrivacyPolicy() {
  return (
    <>
      <Head>
        <title>Privacy Policy | LB Websites</title>
        <meta
          name='description'
          content='Privacy policy for cookie compliance'
        />
      </Head>
      <main className='max-w-4xl mx-auto px-4 py-12 text-gray-600'>
        <h1 className='text-4xl font-bold mb-6'>Privacy & Cookie Policy</h1>
        <p className='mb-4'>
          We use cookies to personalize content and ads, to provide social media
          features and to analyze our traffic.
        </p>
        <h2 className='text-2xl font-semibold mt-6 mb-2'>
          Types of cookies we use:
        </h2>
        <ul className='list-disc pl-6'>
          <li>
            <strong>Essential cookies:</strong> Required for site functionality
            and login sessions.
          </li>
          <li>
            <strong>Preference cookies:</strong> Remember your settings (e.g.,
            language).
          </li>
        </ul>
        <p className='mt-4'>
          You can manage your cookie preferences at any time using the cookie
          banner or your browser settings.
        </p>
        <p className='mt-8 text-sm text-gray-500'>
          Last updated: {new Date().toLocaleDateString()}
        </p>
      </main>
    </>
  );
}
