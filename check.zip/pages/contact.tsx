'use client';

import { useState, useEffect } from 'react';
import Spinner from '../components/Spinner';
import ContactForm from '../components/ContactForm';
import { DefaultSeo } from 'next-seo';

const ContactPage = () => {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      <DefaultSeo
        title='LB Websites | Contact'
        description='Websites for your niche'
        openGraph={{
          type: 'website',
          locale: 'en_IE',
          url: 'https://www.yourwebsite.com',
          site_name: 'LB Websites',
          title: 'LB Websites',
          description: 'Websites for your niche',
          images: [
            {
              url: '/default-cover.jpg',
              width: 1200,
              height: 630,
              alt: 'LB Websites contact page',
            },
          ],
        }}
      />

      <div className='w-full pt-24 pb-20 px-4 flex justify-center'>
        {loading ? (
          <div className='flex justify-center items-center min-h-[50vh]'>
            <Spinner />
          </div>
        ) : (
          <ContactForm />
        )}
      </div>
    </>
  );
};

export default ContactPage;
