export async function createItem(data: any): Promise<string> {
  console.log('Creating item with data:', data);
  return 'mock-item-id';
}
