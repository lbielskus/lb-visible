'use client';

import { FadeLoader } from 'react-spinners';

const Spinner = () => {
  return <FadeLoader color='#ff64c4' />;
};

export default Spinner;
