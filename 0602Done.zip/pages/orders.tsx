import OrdersPage from './orders/OrdersPage';

export default OrdersPage;
